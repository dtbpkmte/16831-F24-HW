All experiment commands are included in the PDF, except for the q4 search question, which just requires running q4_search.py (no arguments).
